package com.springboot;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import com.springboot.model.Complaints;
import com.springboot.model.Customers;
import com.springboot.model.EngineerDuty;
import com.springboot.model.Engineers;
import com.springboot.model.Feedbacks;
import com.springboot.repository.ComplaintRepository;
import com.springboot.repository.CustomerRepository;
import com.springboot.repository.EngineerDutyRepository;
import com.springboot.repository.EngineerRepository;
import com.springboot.repository.FeedbackRepository;

@SpringBootTest
class ComplaintRedressalApplicationTests {
	@Autowired
	ApplicationContext context;
//		@Test
//		void contextLoads() {
//		}
//
//	@Test
//	void addComplaint() {
//		ComplaintRepository repo =  context.getBean(ComplaintRepository.class);
//		Complaints com = new Complaints();
//		//com.setTicketId(4);
//		com.setCustomerEmail("fourthcomplaint04@gmail.com");
//		com.setPincode("000004");
//		com.setComplaint("Facing issuse in landline");
//		//com.setStatus("raised");
//		repo.save(com);
//		}
	//
	//
	// @Test
	//public void readComplaint() {
//		ComplaintRepository repo2 =  context.getBean(ComplaintRepository.class);
//		Optional<Complaints> optionalcomplaints = repo2.findById(9);
//		if(optionalcomplaints.isPresent()) {
//			Complaints com2 = optionalcomplaints.get();
//			System.out.println(com2);
//		}
	//	
	//}
	// 
	// @Test
	// void deleteComplaint() {
//		 ComplaintRepository repo3 =  context.getBean(ComplaintRepository.class);
//		repo3.deleteById(3);
	//	
	// }
	//
	//@Test
	//void updateComplaint() {
//		ComplaintRepository repo4 =  context.getBean(ComplaintRepository.class);
//		Optional<Complaints> optionalcomplaints = repo4.findById(2);
//		Complaints comp4 =null;
//		if(optionalcomplaints.isPresent()) {
//			comp4=optionalcomplaints.get();
//			System.out.println(comp4);
//		}
//		if(comp4 !=null) {
//			comp4.setStatus("Problem Resolved");
//			repo4.save(comp4);
//		}
	//}


	/* Testing of EngineerDuty */

//	@Test
//	void addEngineerDuty() {
//		EngineerDutyRepository repoEng = context.getBean(EngineerDutyRepository.class);
//		EngineerDuty eng = new EngineerDuty();
//		eng.setEngineerDutyId(5);
//		eng.setEngineerEmail("engineer05@gmail.com");
//		eng.setTicketId(6);
//		eng.setCustomerEmail("customer04@gmail.com");
//		repoEng.save(eng);
//	}
	
	//@Test
	//void readEngineerDuty() {
//		EngineerDutyRepository repoEng2 = context.getBean(EngineerDutyRepository.class);
//		Optional<EngineerDuty> optionalengineer = repoEng2.findById(1);
//		if(optionalengineer.isPresent()) {
//			EngineerDuty ed2 = optionalengineer.get();
//			System.out.println(ed2);
//		}
	//}
	//
	////@Test
	////void deleteEngineer() {
////		EngineerDutyRepository repoEng = context.getBean(EngineerDutyRepository.class);
////		repoEng.deleteById(3);
	////}
	//
	//@Test
	//void updateEngineer() {
//		EngineerDutyRepository repoEng3 = context.getBean(EngineerDutyRepository.class);
//		Optional<EngineerDuty> optionalengineer = repoEng3.findById(1);
//		EngineerDuty ed3 = null;
//		if(optionalengineer.isPresent()) {
//			ed3 = optionalengineer.get();
//			System.out.println(ed3);
//		}
//		if(ed3 !=null) {
//			ed3.setEngineerEmail("engineer07@gmail.com");
//			repoEng3.save(ed3);
//		}
	//}

	/* Testing Feedback */

//	@Test
//	void addFeedback() {
//		FeedbackRepository repoFb = context.getBean(FeedbackRepository.class);
//		Feedbacks fb = new Feedbacks();
//		//fb.setFeedbackId(2);
//		fb.setCustomerEmail("customer02@gmail.com");
//		fb.setFeedback("Nice");
//		fb.setTicketId(4);
//		repoFb.save(fb);
//	}
	//
	//@Test
	//void readFeedback() {
//		FeedbackRepository repoFb1 = context.getBean(FeedbackRepository.class);
//		Optional<Feedbacks> optionalFb = repoFb1.findById(1);
//		if(optionalFb.isPresent()) {
//			Feedbacks fb2 = optionalFb.get();
//			System.out.println(fb2);
//		}
	//}
	//
	//@Test
	//void deleteFeedback() {
//		FeedbackRepository repoFb = context.getBean(FeedbackRepository.class);
//		repoFb.deleteById(4);
	//}
	//
	//@Test
	//void updateFeedbacks() {
//		FeedbackRepository repoFb3 = context.getBean(FeedbackRepository.class);
//		Optional<Feedbacks> optionalFb = repoFb3.findById(3);
//		Feedbacks fb3 = null;
//		if(optionalFb.isPresent()) {
//			fb3 = optionalFb.get();
//			System.out.println(fb3);
//		}
	//	
//		if(fb3 !=null) {
//			fb3.setFeedback("Nice work!!");
//			repoFb3.save(fb3);
//		}
	//}

	/* Testing Customer */


//	@Test
//	void AddCustomer() {
//	CustomerRepository repoCust1 = context.getBean(CustomerRepository.class);
//	Customers cust = new Customers();
//	cust.setCustomerEmail("customer05@gmail.com");
//	cust.setCustomerPassword("custo@123");
//	cust.setCustomerName("Customer02");
//	cust.setCustomerMobile("1234567899");
//	cust.setCustomerAddress("H.no.:22/6,canalstreet,nearNichoShop,USA");
//	cust.setCustomerPincode("123474");
//	repoCust1.save(cust);
//	}
	
	//@Test
	//void readCustomer() {
//		CustomerRepository repoCust2 = context.getBean(CustomerRepository.class);
//		Optional<Customers> optionalCust = repoCust2.findById("abc@gmail.com");
//		if(optionalCust.isPresent()) {
//			Customers cust1 = optionalCust.get();
//			System.out.println(cust1);
//		}
	//	
	//}
	//
	//@Test
	//void deleteCustomer() {
//		CustomerRepository repoCust3 = context.getBean(CustomerRepository.class);
//		repoCust3.deleteById("customer04@gmail.com");
	//}
	
//	@Test
//	void updateCustomer() {
//		CustomerRepository repoCust4 = context.getBean(CustomerRepository.class);
//		Optional<Customers> optionalCust2 = repoCust4.findById("abc@gmail.com");
//		Customers cust4 = null;
//		if(optionalCust2.isPresent()) {
//			cust4 = optionalCust2.get();
//			System.out.println(cust4);
//		}
//		
//		if(cust4 !=null) {
//			cust4.setCustomerPassword("abC@123");
//			repoCust4.save(cust4);
//		}
//	}

	                        /*   Engineer Testing    */
//
	@Test
	void AddEngineer() {
		EngineerRepository repoEng01 =context.getBean(EngineerRepository.class);
		Engineers eng01 = new Engineers();
		eng01.setEngineerEmail("engineer02@gmail.com");
		eng01.setEngineerPassword("Engineer02");
		eng01.setEngineerName("Engineer02");
		repoEng01.save(eng01);
	}
	//
	//@Test
	//void readEngineer() {
//		EngineerRepository repoEng01 =context.getBean(EngineerRepository.class);
//		Optional<Engineers> optionalEngineers = repoEng01.findById("engineer@gmail.com");
//		Engineers eng04 = null;
//		if(optionalEngineers.isPresent()) {
//			System.out.println(eng04);
//		}
	//	
	//}
	
	
}
